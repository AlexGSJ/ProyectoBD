
package practica2;

//import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
      public static Connection getConexion(){
        String connectionUrl =
                "jdbc:sqlserver:ALEX_GONZALEZ\\SERVIDOR1:1433;"
                        + "database=AdventureWorks2019;"
                        + "user=sa;"
                        + "password=1234;"
                        + "encrypt=true;"
                        + "trustServerCertificate=true;"
                        + "loginTimeout=30;";

        try {
            Connection con = DriverManager.getConnection(connectionUrl);
            return con;
        }
        // Handle any errors that may have occurred.
        catch (SQLException ex) {
         System.out.println(ex.toString());
         return null;
        }
}}
